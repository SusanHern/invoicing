"name" , "descp", "streetnameno", "buildingnameno", "suburb", "town", "state", "country", "phone"
<form name='workform' method='post' action='processaddress.php'>
<label>Name</label><br>
<input type='text' name='name' /><br>
<label>Description</label><br>
<input type='text' name='descp' /><br>
<label>Street Name Number</label><br>
<input type='text' name='street' /><br>
<label>Building Name and Number</label><br>
<input type='text' name='building' /><br>
<label>Suburb</label><br>
<input type='text' name='suburb' /><br>
<label>Town</label><br>
<input type='text' name='town' /><br>
<label>State</label><br>
<input type='text' name='state' /><br>
<label>Country</label><br>
<input type='text' name='country' /><br>
<label>Phone</label><br>
<input type='text' name='phone' /><br>

<input type='submit' value='submit' name='submit' /></form>