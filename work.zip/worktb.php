date site title descps words byline rate total
<?
require "libsq.php";
$connection = "conf.php";
$tb = "work";
$idfield = "wk_id";
$fieldsarray = array("date" , "site", "title", "descps", "words", "byline", "rate", "total", "other");
maketb($connection, $tb, $idfield, $fieldsarray);
?>