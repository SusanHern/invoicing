<?
include "conf.php";
$sq = $db->query("DELETE FROM work WHERE wk_id = '10'");