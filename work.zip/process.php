<?
require "libsq.php";

$date = $_POST[date];
$connection = "conf.php";
$tb = "work";

$descps = $_POST[descps];
$site = $_POST[site];
$title = $_POST[title];
$words = $_POST[words];
$byline = $_POST[byline];
$rate = $_POST[rate];
$total = $rate * $words;
$other = $_POST[other];

$fieldsarray = array("date" , "site", "title", "descps", "words", "byline", "rate", "total", "other");
$fieldsarray2 = array($date, $site, $title, $descps, $words, $byline, $rate, $total, $other);

instb($connection, $tb, $fieldsarray, $fieldsarray2);
?>
