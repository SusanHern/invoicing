<?
require "libsq.php";
$connection = "conf.php";
$tb = "site";
$idfield = "site_id";
$fieldsarray = array("name" , "descp");
maketb($connection, $tb, $idfield, $fieldsarray);
?>