<form name='workform' method='post' action='siteprocess.php'>
<label>Name</label><br>
<input type='text' name='name' /><br>
<input type='submit' value='submit' name='submit' /></form>
