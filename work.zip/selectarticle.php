<?
include "conf.php";
echo "<table>";
$sq = $db->query("SELECT * FROM work");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {
echo "<tr>";
echo "<td>$row[wk_id]</td>";
echo "<td>$row[date]</td>";
echo "<td>$row[title]</td>";
echo "<td>$row[descps]</td>";
echo "<td>$row[site]</td>";
echo "<td>$row[words]</td>"; 
echo "<td>$row[byline]</td>";
echo "<td>$row[total]</td>";
echo "</tr>";
} 
echo "</table>";
?>
date site title descps words byline rate total