<form name='workform' method='post' action='process.php'>
<label>Date</label><br>
<input type='date' name='date' /><br>
<label>Site</label><br>
<input type='text' name='site' /><br>
<label>Title</label><br>
<input type='text' name='title' /><br>
<label>Description</label>
<input type='text' name='descps' /><br>
<label>Words</label><br>
<input type='text' name='words' /><br>
<label>Rate</label><br>
<input type='text' name='rate' /><br>
<label>Byline</label><br>
<input type='text' name='byline' /><br>
<input type='submit' value='submit' name='submit' /></form>

