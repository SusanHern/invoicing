<?
require "libsq.php";

$name = $_POST[name];
$connection = "conf.php";
$tb = "site";
$namex = 'name';
$descp = 'descp';
$sitedescp = 'website';
$fieldsarray = array($namex , $descp);
$fieldsarray2 = array($name, $sitedescp);

instb($connection, $tb, $fieldsarray, $fieldsarray2);