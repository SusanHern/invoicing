<?
copy("https://petya.convertio.me/p/tVbR3RzCOzRJ8MzfBG0oOw/1f942050271adb679793b7f839fc86d7/invoice2WNOTW.docx", "invoicesusanhern2.docx");