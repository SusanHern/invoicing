
<script>
function validateForm()
{
var x=document.forms["rform"]["name"].value;
if (x==null || x=="")
{
alert("Name must be filled out");
return false;
} 


var xc=document.forms["rform"]["email"].value;
if (xc==null || xc=="")
{
alert("email must be supplied");
return false;
} 


} 
</script>
<!DOCTYPE html>
<html lang="en"><head><style>
@import "https://fonts.googleapis.com/css?family=Raleway:100,300,600";
.dh {font-family: "Raleway", Arial, Helvetica, sans-serif;
text-align:center;}
.he {font-family: "Raleway", Arial, Helvetica, sans-serif;
		font-size: 20pt;
		font-weight: 400;
text-align:center;
color:gray;
margin-bottom:20px;} 
p { font-family: "Raleway", Arial, Helvetica, sans-serif; }</style><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><meta name="description" content="Contact Swiftwebguru for web design from R199"><meta name="author" content=""><link rel="icon" href="../../favicon.ico"><title>Contact for webdesign from R199</title><!-- Bootstrap core CSS --><link rel="stylesheet" href="bootstrap.min.css"><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script><script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script><!-- Custom styles for this template --><link href="narrow-jumbotron.css" rel="stylesheet"></head><body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills float-right"><li class='nav-item'><a style='background:#7198A7;color:white;' class='nav-link active' href='index.php'>Home<span class='sr-only'>(current)</span></a></li><li class='nav-item'><a style='color:#7198A7;background:white;' class='nav-link' href='contact.php'>Contact</a></li><li class='nav-item'><a style='color:#7198A7;background:white;' class='nav-link' href='about.php'>About</a></li><li class='nav-item'><a style='color:#7198A7;background:white;' class='nav-link' href='prices.php'>Pricing</a></li>

          </ul>
        </nav>
        <h3  class="text-muted">SwiftWebGuru</h3>
      </div>
      <div class='container'><center><img src="headerimg.jpg" class='rounded-circle' class="img-fluid" alt="Responsive image"></center>


      <div class="row marketing">
        <div class="col-lg-6">
          <center><h2 class='dh'>Contact</h2></center><hr>
          <p></div>

        
          
        <div class="col-md-12"><h4 class='he'>Add your Name and Email to your message. Expect a response in 24hrs.</h4><p class='lead'><address>
        <strong>SwiftWebGuru</strong><br>2 Cuyler Rd<br>Towerby, Johannesburg, Gauteng, 2190<br><abbr title='Phone'>P:</abbr>0726060893<br><abbr title='Phone'>P:</abbr>0726050893</address><address><strong>SwiftWebGuru</strong><br><a href='mailto:info@swiftwebguru'>Contact</a></address></p><hr><p><form name='rform' onsubmit='return validateForm();' method='post' class="form-horizontal" action="processcontact.php">
          <div class="form-group">
    <label class="control-label col-sm-4" for="name">Name:</label>
    <div class="col-sm-12"> 
      <input type="text" class="form-control" name='name' id="name" placeholder="Enter name">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-4" for="email">Email:</label>
    <div class="col-sm-12">
      <input type="email" class="form-control" name='email' id="email" placeholder="Enter email">
    </div>
  </div>
<div class='form-group'><label class="control-label col-sm-4" for='descp'>Enter Message :</label><br /><div class="col-sm-12"><textarea cols='40' rows='10' name='message'></textarea></div></div>
<div class='form-group'>
<?
require "Robochkr.php";
?>
</div>


  <div class="form-group"> 
    <div class="col-sm-10">
      <button type="submit" class="btn btn-lg btn-primary btn-block">Send Message</button>
    </div>
  </div>
</form> </p></div><footer class="footer">
        <p>&copy; SwiftWebGuru</p>
      </footer>

    </div> <!-- /container -->

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="ie10-viewport-bug-workaround.js"></script>
  </body>
</html>



