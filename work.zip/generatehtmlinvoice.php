<?
$file = 'invoice2WNOTW.html';

$today = date("Y-m-d");
$days = 'August 28th 2018';
$daysend = 'Sept 3rd 2018';
$str = "<html><head><title>Invoice No 1</title></head><body>
<table border='1' width='800px'><th>Address</th><th>Invoice No</th><th></th><th></th><th></th>
<tr>
<td colspan='1'>
<ul>
<li>Name: Susan Hern</li>
<li>Street: 2 Cuyler Rd</li>
<li>Suburb: Towerby</li>
<li>Town: Johannesburg</li>
<li>State: Gauteng</li>

</td>

<td colspan='4'>
<ul>
<li>Date: " . $today . "</li></ul>

</td>
</tr>
<tr>
<td colspan='1'>To:  New Age Content Services, LLP

B-406 Eco Heights Marol, Andheri East, Mumbai, India</td><td colspan='4'>
<ul>
<li>From</li>
<li> " . $days . "</li>
<li>To</li>
<li> " . $daysend . "</li>

</ul>

</td>
</tr>


<tr>
<td>No</td><td>Date</td><td>Name of Article</td><td>Number of words</td><td>Byline</td></tr>";
echo "$str";
$fp = fopen($file, "w");
fwrite($fp, $str);

include "conf.php";


$sq = $db->query("SELECT * FROM work WHERE date BETWEEN '2018-09-04' AND '2018-09-12'");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {
$words[] = $row[words];
$rate = $row[rate];

$arr = array('1', '2', '3' , '4');
$val = "<tr><td>" . $row[wk_id]. "</td><td>" . $row[date] . "</td><td>" . $row[title] . "</td><td>" . $row[words] . "</td><td>" . $row[byline] . "</td></tr>";
echo $val;
$fp2 = fopen($file, "a+");
fwrite($fp2, $val);
} 
$finwords = array_sum($words);
$rates = 1;
$fintot = $finwords/100;

$val2 = "<tr><td colspan='3'>Total Words: " . $finwords . "</td><td> Rate per word: " . $rates . 'c</td><td colspan="1"> Total $' . $fintot . "</td></tr>";

echo "$val2";
$fp3 = fopen($file, "a+");
fwrite($fp3, $val2);


$end = "</table></body></html>";
echo "$end";
$fp4 = fopen($file, "a+");
fwrite($fp4, $end);