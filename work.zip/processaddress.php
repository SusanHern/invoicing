<?
require "libsq.php";

$name = $_POST[name];
$connection = "conf.php";
$tb = "address";

$descp = $_POST[descp];
$streetnameno = $_POST[street];
$buildingnameno = $_POST[building];
$suburb = $_POST[suburb];
$town = $_POST[town];
$state = $_POST[state];
$country = $_POST[country];
$phone = $_POST[phone];

$fieldsarray = array("name" , "descp", "streetnameno", "buildingnameno", "suburb", "town", "state", "country", "phone");
$fieldsarray2 = array($name, $descp, $streetnameno, $buildingnameno, $suburb, $town, $state, $country, $phone);

instb($connection, $tb, $fieldsarray, $fieldsarray2);
?>
