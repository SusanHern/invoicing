<?
require "libsq.php";
$connection = "conf.php";
$tb = "address";
$idfield = "ad_id";
$fieldsarray = array("name" , "descp", "streetnameno", "buildingnameno", "suburb", "town", "state", "country", "phone");
maketb($connection, $tb, $idfield, $fieldsarray);
?>