<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><meta name="description" content=""><meta name="author" content=""><link rel="icon" href="favicon.ico"><title>Articles Category Manager</title><link href="../css/bootstrap.min.css" rel="stylesheet"><link href="narrow-jumbotron.css" rel="stylesheet"></head><body><div class="container"><div class="header clearfix"><nav><ul class="nav nav-pills float-right">
<li class="nav-item"><a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a></li>
<li class="nav-item">
<a class="nav-link" href="addimages.php">Add Content</a></li>
<li class="nav-item"><a class="nav-link" href="editlead.php">Edit Content</a></li>
</ul>
</nav>
<h3 class="text-muted">Product Management</h3>
</div>
<div class="row marketing">
<div class="col-lg-6">
<h4>ViewArticle Category.</h4><p>
//php here
<?
require "conf.php";
$sq = $db->query("SELECT * FROM prodCategorytb");
while($row = $sq->fetchArray(SQLITE3_ASSOC)) {

echo "$row[prodcate_title]<br>"; } 
?>
          
</p>

          
        </div>

      </div>

      <footer class="footer">
        <p>&copy; Itsasmartsolve</p>
      </footer>

    </div> <!-- /container -->

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="ie10-viewport-bug-workaround.js"></script>
  </body>
</html>